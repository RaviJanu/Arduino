
##### We are migrating this code repo to 2 separate repositories. This repo, will not be updated.
…
#### This is the Code you are looking for:

[Arduino Software for Pulse Sensor](https://github.com/WorldFamousElectronics/PulseSensor_Amped_Arduino)

[Processing Software for Pulse Sensor](https://github.com/WorldFamousElectronics/PulseSensor_Amped_Processing_Visualizer)
###### [ You need to have the Arduino Software Installed to use Processing Software ]
